package com.company.utilitytool.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/backup")
public class BackupController {

    @PostMapping
    public Map<String,String> backup(@RequestParam String cluster,
                                     @RequestParam String namespace){
        return Map.of("status","Backup created successfully");
    }
}
