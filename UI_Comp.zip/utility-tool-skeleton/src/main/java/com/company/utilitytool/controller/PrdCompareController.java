package com.company.utilitytool.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/prd")
public class PrdCompareController {

    @GetMapping("/compare")
    public List<Map<String,String>> compare(){
        return List.of(
                Map.of("service","user-service","field","replicas","before","2","after","3"),
                Map.of("service","payment-service","field","image","before","v1","after","v2")
        );
    }
}
