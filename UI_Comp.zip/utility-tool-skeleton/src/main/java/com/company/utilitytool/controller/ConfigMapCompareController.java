package com.company.utilitytool.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/configmap")
public class ConfigMapCompareController {

    @GetMapping("/compare")
    public List<Map<String,Object>> compare(){
        return List.of(
                Map.of("service","order-service",
                        "differences", List.of(
                                Map.of("key","DB_URL","pipeline","old","cluster","new")
                        ))
        );
    }
}
