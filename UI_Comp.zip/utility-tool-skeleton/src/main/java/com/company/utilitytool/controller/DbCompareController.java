package com.company.utilitytool.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/db")
public class DbCompareController {

    @PostMapping("/compare")
    public Map<String,Object> compare(@RequestBody Map<String,Object> request){
        return Map.of(
                "status","Compared",
                "differences", List.of(
                        Map.of("id","101","column","status","before","ACTIVE","after","INACTIVE"),
                        Map.of("id","102","column","amount","before","1000","after","1200")
                )
        );
    }
}
