package com.company.utilitytool.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/cluster")
public class ClusterController {

    @GetMapping("/pods")
    public List<Map<String,String>> pods(@RequestParam String cluster,
                                         @RequestParam String namespace) {
        return List.of(
                Map.of("name","user-service","status","Running"),
                Map.of("name","order-service","status","Running"),
                Map.of("name","payment-service","status","CrashLoopBackOff")
        );
    }

    @PostMapping("/reconnect")
    public Map<String,String> reconnect(@RequestParam String cluster){
        return Map.of("status","Reconnected to " + cluster);
    }
}
